/* @(#) pw.h 1.1 1/27/86 17:46:53 */
/*ident	"@(#)cfront:incl/pw.h	1.1"/
extern char* logname(),
             recmp (const char* ...), 
             regexp (const char* ...);
