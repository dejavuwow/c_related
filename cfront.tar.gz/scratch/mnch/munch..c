main(){ exit(0); }
