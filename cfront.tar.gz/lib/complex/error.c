/*#ident	"@(#)cfront:lib/complex/error.c	1.3"*/

#include "complex.h"

int
complex_error( c_exception& )
{
	return( 0 );
}
