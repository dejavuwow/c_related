/* @(#) const.h 1.2 1/27/86 17:47:31 */
/*ident	"@(#)cfront:lib/complex/const.h	1.2"*/
#define	ABS(x)	((x<0) ? -(x) : x)

#define	MAX_EXPONENT	88.0
#define MIN_EXPONENT	-88.0

#define	GREATEST 1.701411834604692293e38
