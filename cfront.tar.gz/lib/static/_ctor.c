/* @(#) _ctor.c 1.2 1/27/86 17:47:54 */
/*ident	"@(#)cfront:lib/static/_ctor.c	1.2"*/
typedef void (*PFV)();
extern PFV _ctors[] = { 0 };
