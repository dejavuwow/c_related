/* @(#) _dtor.c 1.2 1/27/86 17:47:55 */
/*ident	"@(#)cfront:lib/static/_dtor.c	1.2"*/
typedef void (*PFV)();
extern PFV _dtors[] = { 0 };
